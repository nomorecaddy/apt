Project: Android
Description: Library of QuickCalls and response maps for automating Android mobile phones via the Android Debug Bridge, ADB
Category: library
Class: Community