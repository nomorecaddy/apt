Project: <name>
Description: <Some wording about what the project does or is used for>
Category: <"library", "automation", or "framework">
Class: <"Community", "Tested by Spirent", "Reference">