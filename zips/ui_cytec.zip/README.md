### Project Information:
Project: Cytec Control Module  
Description: LAN Telnet QuickCalls for IF-9 or IF-11 models  
Category: library  
Class: Community  
  
___
### 1 QuickCall Library in project://ui_cytec
### Library: project://ui_cytec/session_profiles/cytec.fftc
___
### latch

Argument | Description
------------ | -------------
port | 
### unlatch

Argument | Description
------------ | -------------
port | 
### clear_card

Argument | Description
------------ | -------------
cardId | 
