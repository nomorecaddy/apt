1 QuickCall Library in project://ui_cytec
## Library: project://ui_cytec/session_profiles/cytec.fftc
### latch

Argument | Description
------------ | -------------
port | 
### unlatch

Argument | Description
------------ | -------------
port | 
### clear_card

Argument | Description
------------ | -------------
cardId | 
