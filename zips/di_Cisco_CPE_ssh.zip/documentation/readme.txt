Project: Cisco CPE
Description: Automation library for Cisco CPE devices with emphasis on voice testing
Category: library
Class: Community