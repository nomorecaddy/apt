### Project Information:
Project: JDSU  
Description: QuickCalls and response maps   
Category: library  
Class: Community  
  
___
### 1 QuickCall Library in project://di_JDSU
### Library: project://di_JDSU/session_profiles/jdsu_quickcall_lib.fftc
___
Description:  
REST quick call library for JDSU session  
  
  
### versionQuery
### login

Argument | Description
------------ | -------------
username | 
password | 
url | 
### SART_open

Argument | Description
------------ | -------------
url | 
### MUS

Argument | Description
------------ | -------------
cookie | 
url | 
### add_DNA

Argument | Description
------------ | -------------
DNA_List | 
url | 
### deciphering
### lte_call_trace

Argument | Description
------------ | -------------
url | 
### lte_filter

Argument | Description
------------ | -------------
url | 
IMSI | 
### start_recording

Argument | Description
------------ | -------------
url | 
### stop_recording

Argument | Description
------------ | -------------
url | 
### close_software

Argument | Description
------------ | -------------
url | 
### Start_Capture

Argument | Description
------------ | -------------
url | 
DNA_List | 
IMSI | 
username | 
password | 
### logout

Argument | Description
------------ | -------------
url | 
### Stop_Capture

Argument | Description
------------ | -------------
Trace_Overview_Path | 
Trace_Decode_Path | 
url | 
