Project: Abacus
Description: Response maps and QuickCalls for Abacus VOIP and PSTN test automation
Category: library
Class: Tested by Spirent