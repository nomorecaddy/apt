### Project Information:
Project: NewBridge DSLAM  
Description: QuickCalls and response maps useful for building system tests automating the NewBridge DSLAM  
Category: library  
Class: Community  
  
___
### 1 QuickCall Library in project://di_dslam_newbridge
### Library: project://di_dslam_newbridge/session_profiles/newbridge_350.fftc
___
### login
### getFootprint

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
footprint_data | 
### getLinkState

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### setDslamProfile

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
dslam_profile | 
args | 
### getPortId

Argument | Description
------------ | -------------
card_port_num | \t
### getCommandLogs

Argument | Description
------------ | -------------
card_port_num | 
log_file | 
