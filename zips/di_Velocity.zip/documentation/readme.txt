Project: Velocity REST
Description: QuickCalls useful for automating Velocity via its REST API
Category: framework
Class: Community