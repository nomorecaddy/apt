# Initial comments
This project contains examples used in Spirent product demos. It contains QC examples that can be used to get your test automation started. Most of the development is done from the STC REST.

Feel free to use and modify as needed. Also, contribute additional QCs that other community members may be able to use.

Note: QCs that reference SQLite. STC is going to deprecate that functionality so use it knowing you may have to migrate to another model.

# Future comments …
