1 QuickCall Library in project://ui_wifi_host
## Library: project://ui_wifi_host/session_profiles/wifi_host_remote_base_qc.fftc
### getWifiInterfaceName
### getWifiInterfaceState
### enableWifiInterface

Argument | Description
------------ | -------------
ifName | 
### disableWifiInterface

Argument | Description
------------ | -------------
ifName | 
### getWifiLinkState
### connectWifi

Argument | Description
------------ | -------------
ifName | 
profileName | 
### disconnectWifi

Argument | Description
------------ | -------------
ifName | 
### getProfiles
### waitForWifiLink
### wifiPing

Argument | Description
------------ | -------------
host | 
count | 
gateway | 
