### Project Information:
Project: Abstract Test Cases  
Description: These test cases show how abstract system tests are built, automating either Cisco or Juniper device with STC and verifying frame contents with Wireshark  
Category: automation  
Class: Community  
  
___
