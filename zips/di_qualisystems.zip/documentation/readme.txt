Project: CloudShell
Description: QuickCalls for automating Quali CloudShell
Category: framework
Class: Community