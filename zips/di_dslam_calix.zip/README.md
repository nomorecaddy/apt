1 QuickCall Library in project://di_dslam_calix
## Library: project://di_dslam_calix/session_profiles/calix_vdsl_base.fftc
### login
### getFootprint

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
footprint_data | 
### convertPort

Argument | Description
------------ | -------------
port | 
### getCounters

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
counter_data | 
time | 
### getLinkState

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### disablePorts

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### enablePorts

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### setDslamProfile

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
dslam_profile | 
args | 
### setDslamProfile_old

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
dslam_profile | 
### setprofile_none

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_single

Argument | Description
------------ | -------------
card_port_num | 
session | 
args | 
### setprofile_10240x640_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_11776x1024_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_12128x5120_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_12128x896_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_15008x1504_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_15136x3072_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_1536x640_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_1536x896_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_1760x288_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_1760x576_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_18128x896_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_20000x2016_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_20128x5120_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_20128x896_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_20Mx2M_LCIPTV

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_25024x2016_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_25Mx2M_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_30016x2016_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_3072x2048_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_3072x640_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_35136x15136_12a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_35136x3072_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_3520x576_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_40000x5024_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_40128x20128_12a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_40128x5120_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_40Mx5M_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_50016x5024_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_5120x3072_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_5120x5120_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_5120x896_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_5888x896_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_640x256_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_6SNR_8D_1INP_12a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_6SNR_8D_1INP_12a_UPBO

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_6SNR_8D_1INP_17a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_6SNR_8D_1INP_17a_UPBO

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_6SNR_8D_1INP_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_6SNR_8D_1INP_8a_UPBO

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_7168x2048_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_7168x5120_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_7168x896_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_896x288_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_896x448_LCTL

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_9SNR_8x5D_2INP_12a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_9SNR_8x5D_2INP_17a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_9SNR_8x5D_2INP_8a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_9SNR_8x5D_2x1INP_12a_UPBO

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_9SNR_8x5D_2x1INP_17a_UPBO

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_9SNR_8x5D_2x1INP_8a_UPBO

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V1_5Mx768K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V10MX1M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V10Mx10M_IPC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V10Mx768K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V12Mx1_5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V12Mx5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V15Mx768K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V20Mx1_5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V20Mx20M_IPC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V20Mx5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V20Mx896K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V25Mx1_5M_IPTV

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V30Mx1_5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V30Mx30M_IPC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V3Mx3M_IPC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V3Mx768K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V40Mx20M_12a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V40Mx20M_17a

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V40Mx40M_IPC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V40Mx5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V40Mx5M_IPTV

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V4Mx1M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V5Mx5M_IPC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V60Mx5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V60Mx5M_IPTV

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V6Mx1_5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V6Mx768K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_V7Mx7M_IPC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_10240x640

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_11776x1024_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_11776x896_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_12128x896

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_18128x896

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_20128x896

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_32000x2048

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_32000x2048_IPTV

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_6SNR_8D_1INP_2p

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_6SNR_8D_1INP_2pATM

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_9440x896_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_AF1_5Mx768K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_AF3Mx768K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_1536x640

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_1536x896

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_1760x288_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_1760x576_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_256x256

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_3072x640

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_3520x576_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_3520x736_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_4704x576_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_5120x896

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_576x288_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_5888x896_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_640x256

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_7072x576_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_7168x896

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_8032x1024

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_8032x1024_ansi

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_8032x1024_dmt

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_896x288_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_896x448_LC

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setMode

Argument | Description
------------ | -------------
card_port_num | 
mode | atm | ptm
### bondPorts

Argument | Description
------------ | -------------
card_port_num | List of two "card/slot/port"<br><br>Example:<br>1/2/1 1/2/2
mode | atm | ptm
alias | If not specified, default to "GROUP $shelf_$slot_$port".
### unbondPorts

Argument | Description
------------ | -------------
card_port_num | List of card/slot/port<br><br>Example:<br>1/2/1 1/2/2<br>
mode | atm | ptm
alias | If not specified, default to "GROUP $shelf_$slot_$port".
### setCrossConnect

Argument | Description
------------ | -------------
card_port_num | List of card/slot/port<br><br>Examples:<br>1/1/1<br>1/2/1 1/2/2<br>
protocol | dhcp | pppoe | multicast
mode | atm | ptm
vlan_info | 
### removeCrossConnect

Argument | Description
------------ | -------------
card_port_num | List of card/slot/port<br><br>Examples:<br>1/1/1<br>1/2/1 1/2/2<br>
protocol | dhcp | pppoe | multicast
mode | atm | ptm
