2 QuickCall Libraries in project://ui_mail_com
## Library: project://ui_mail_com/referenceSessionProfile/Mail_pop3_ref_session_profile_quickcall_library.fftc
## Library: project://ui_mail_com/referenceSessionProfile/mailQuickcallLibrary.fftc
## Headline: QC library for mail sessions
Description:  
This is a generic QC library for mail sessions  
  
