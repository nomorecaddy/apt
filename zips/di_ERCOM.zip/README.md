1 QuickCall Library in project://di_ERCOM
## Library: project://di_ERCOM/session_profiles/ercom_qclib.fftc
### getBladeStatus
### getLbladeStatus
### getLbladeCount
### getPlatforms
### getCurrentBundleInfo
### getInstalledBundlesInfo
### rebootBlade
### DiskSpaceSmall
### DiskSpaceTooSmall
### getDiskSpaceInfos
### executionState

Argument | Description
------------ | -------------
platform_id | 
### ISIDLE
### stopCurrentTest

Argument | Description
------------ | -------------
platform_id | 
### directExecution

Argument | Description
------------ | -------------
platform_id | 
Uid | 
### setTestParams

Argument | Description
------------ | -------------
platform_id | 
### getTestParams

Argument | Description
------------ | -------------
platform_id | 
