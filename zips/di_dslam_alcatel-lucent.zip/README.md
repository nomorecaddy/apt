7 QuickCall Libraries in project://di_dslam_alcatel-lucent
## Library: project://di_dslam_alcatel-lucent/session_profiles/alu_7300.fftc
### convertPort

Argument | Description
------------ | -------------
portid | 
### setprofile_ABLT-F_1_TR67_INT_RA

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_ABLT-F_1_TR67_FAST_RA

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_ABLT-F_1_B2P_RA_F_30000k

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_ABLT-F_1_B2P_RA_I_30000k

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_ADLT-K_1_TR67_INT_RA

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_ADLT-K_1_TR67_FAST_RA

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_ADLT-N_1_TR67_INT_RA

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_ADLT-N_1_TR67_FAST_RA

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_SMLT-A_1_RA_2304K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### getFootprint_ABLT-F_1

Argument | Description
------------ | -------------
card_port_num | 
footprint_data | 
session | 
### getFootprint_ADLT-K_1

Argument | Description
------------ | -------------
card_port_num | 
footprint_data | 
session | 
### getFootprint_ADLT-N_1

Argument | Description
------------ | -------------
card_port_num | 
footprint_data | 
session | 
### getFootprint_SMLT-A_1

Argument | Description
------------ | -------------
card_port_num | 
footprint_data | 
session | 
### getLinkState_ABLT-F_1

Argument | Description
------------ | -------------
card_port | 
session | 
### getLinkState_ADLT-K_1

Argument | Description
------------ | -------------
card_port | 
session | 
### getLinkState_ADLT-N_1

Argument | Description
------------ | -------------
card_port | 
session | 
### getLinkState_SMLT-A_1

Argument | Description
------------ | -------------
card_port | 
session | 
### login
### logout
### getLinkState

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
### getFootprint

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
footprint_data | 
### setDslamProfile

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
dslam_profile | 
## Library: project://di_dslam_alcatel-lucent/session_profiles/alu_7302fd.fftc
### convertPort

Argument | Description
------------ | -------------
portid | 
### setprofile_NALT-D_1_TR67_INT_RA

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NALT-D_1_TR67_FAST_RA

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NALT-D_1_B2P_RA_F_30000k

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NALT-D_1_B2P_RA_I_30000k

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NALT-D_1

Argument | Description
------------ | -------------
card_port_num | 
profile_name | 
spectrum | 
session | 
### setprofile_NSLT-A_1_RA_2304K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NSLT-A_1_RA_5696K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NSLT-A_1_RA_5696K_EFM

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NSLT-A_1_RA_11392K_4w

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NSLT-A_1_RA_11392K_4w_EFM

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NSLT-A_1_RA_22784K_8w

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NSLT-A_1_RA_22784K_8w_EFM

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_NSLT-A_1

Argument | Description
------------ | -------------
card_port_num | 
session | 
### getFootprint_NALT-D_1

Argument | Description
------------ | -------------
card_port_num | 
footprint_data | 
session | 
### getLinkState_NALT-D_1

Argument | Description
------------ | -------------
card_port | 
session | 
### getFootprint_NSLT-A_1

Argument | Description
------------ | -------------
card_port_num | 
footprint_data | 
session | 
### getLinkState_NSLT-A_1

Argument | Description
------------ | -------------
card_port | 
session | 
### login
### logout
### getLinkState

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
### getFootprint

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
footprint_data | 
### setDslamProfile

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
dslam_profile | 
## Library: project://di_dslam_alcatel-lucent/session_profiles/alu_7302xd.fftc
### convertPort

Argument | Description
------------ | -------------
portid | 
### getFootprint_EBLT

Argument | Description
------------ | -------------
card_port_num | 
footprint_data | 
session | 
### getLinkState_EBLT

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EBLT_TR67_INT_RA

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EBLT_TR67_FAST_RA

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EBLT_B2P_RA_F_30000k

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EBLT_B2P_RA_I_30000k

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EBLT

Argument | Description
------------ | -------------
card_port_num | 
profile_name | 
session | 
### setprofile_SMLT_RA_2304K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_SMLT_RA_5696K

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_SMLT_RA_5696K_EFM

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_SMLT_RA_11392K_4w

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_SMLT_RA_11392K_4w_EFM

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_SMLT_RA_22784K_8w

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_SMLT_RA_22784K_8w_EFM

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_SMLT

Argument | Description
------------ | -------------
card_port_num | 
session | 
### getFootprint_SMLT

Argument | Description
------------ | -------------
card_port_num | 
footprint_data | 
session | 
### getLinkState_SMLT

Argument | Description
------------ | -------------
card_port | 
session | 
### login
### logout
### getLinkState

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
### getFootprint

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
footprint_data | 
### setDslamProfile

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
dslam_profile | 
## Library: project://di_dslam_alcatel-lucent/session_profiles/alu_7330.fftc
### login
### getFootprint

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
footprint_data | 
### getLinkState

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### disablePorts

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### enablePorts

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### getCounters

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
counter_data | 
time | 
### getCountersOld

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
counter_data | 
### setDetailedResultsOn

Argument | Description
------------ | -------------
card_port_num | 
onoff | 
session | 
### setDetailedResultsOff

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
### setProfile_EVLT_base

Argument | Description
------------ | -------------
card_port_num | 
spectrum_profile | 
line_profile | 
### setProfile_EVLT_BOND_base

Argument | Description
------------ | -------------
card_port_num | 
spectrum_profile | 
line_profile | 
service_profile | 
### setprofile_EVLT_none

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS09_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS10_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS11_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS12_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS13_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS14_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_7330_uncapped_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS07_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS08_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS09_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS10_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS11_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS12_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS13_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_AA8d_RA_I_096_056

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_uncapped

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS09

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS10

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS11

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS12

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_2Mx2M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_2Mx2M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_4Mx4M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_4Mx4M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_4Mx2M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_4Mx2M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_3Mx1M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_3Mx1M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_6Mx1M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_6Mx1M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_12Mx1DOT5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_12Mx1DOT5M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_18Mx1DOT5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_18Mx1DOT5M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_24Mx3M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_24Mx3M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_45Mx6M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_45Mx6M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_AA17A_RA_F_150_150

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_AA17A_RA_I_150_150

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS07

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS08

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS09

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS10

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS11

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS12

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_2Mx2M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_4Mx4M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_3Mx1M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_6Mx1M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_12Mx1DOT5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_18Mx1DOT5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_24Mx3M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_45Mx6M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_2Mx2M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_4Mx4M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_3Mx1M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_6Mx1M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_12Mx1DOT5M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_18Mx1DOT5M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_24Mx3M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_45Mx6M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_AA17a_RA_I_150_096

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_AA8d_RA_I_096_056

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_AA8d_UPBO_FX_I_027_002

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_7330_uncapped

Argument | Description
------------ | -------------
card_port_num | 
session | 
### showCarrierDataDetail

Argument | Description
------------ | -------------
direction | far-end or near-end 
interface | interface identification
## Library: project://di_dslam_alcatel-lucent/session_profiles/alu_7450.fftc
### clear_DHCP_Table
### login
## Library: project://di_dslam_alcatel-lucent/session_profiles/nokia_7302_isam.fftc
## Headline: Nokia 7302 ISAM QuickCall Library
Description:  
NOTES:  
1. All getFootprint commands are now using xml option. This allows for Xmap queries and eliminates the need for a response map.  
  
### getFootprint

Argument | Description
------------ | -------------
card_port_num | 
footprint_data | 
### getLinkState

Argument | Description
------------ | -------------
card_port | 
### setDslamProfile

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
dslam_profile | 
## Library: project://di_dslam_alcatel-lucent/session_profiles/nokia_7330.fftc
### login
### getFootprint

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
footprint_data | 
### getLinkState

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### disablePorts

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### enablePorts

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### setDslamProfile

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
dslam_profile | 
args | 
### getCounters

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
counter_data | 
time | 
### getCountersOld

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
counter_data | 
### setDetailedResultsOn

Argument | Description
------------ | -------------
card_port_num | 
onoff | 
session | 
### setDetailedResultsOff

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
### setProfile_EVLT_base

Argument | Description
------------ | -------------
card_port_num | 
spectrum_profile | 
line_profile | 
### setProfile_EVLT_BOND_base

Argument | Description
------------ | -------------
card_port_num | 
spectrum_profile | 
line_profile | 
service_profile | 
### setprofile_EVLT_none

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_V2_BB8b_RA_f_150_150

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS10_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS11_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS12_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS13_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS14_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_7330_uncapped_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS07_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS08_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS09_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS10_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS11_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS12_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS13_17mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_AA8d_RA_I_096_056

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_uncapped

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS09

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS10

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS11

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_UVCLASS12

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_2Mx2M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_2Mx2M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_4Mx4M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_4Mx4M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_4Mx2M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_4Mx2M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_3Mx1M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_3Mx1M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_6Mx1M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_6Mx1M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_12Mx1DOT5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_12Mx1DOT5M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_18Mx1DOT5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_18Mx1DOT5M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_24Mx3M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_24Mx3M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_45Mx6M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_BOND_ASE_45Mx6M_17Mhz

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_AA17A_RA_F_150_150

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_AA17A_RA_I_150_150

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS07

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS08

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS09

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS10

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS11

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_UVCLASS12

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_2Mx2M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_4Mx4M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_3Mx1M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_6Mx1M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_12Mx1DOT5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_18Mx1DOT5M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_24Mx3M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_45Mx6M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_2Mx2M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_4Mx4M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_3Mx1M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_6Mx1M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_12Mx1DOT5M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_18Mx1DOT5M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_24Mx3M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_ASE_45Mx6M_17M

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_AA17a_RA_I_150_096

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_AA8d_RA_I_096_056

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_AA8d_UPBO_FX_I_027_002

Argument | Description
------------ | -------------
card_port_num | 
session | 
### setprofile_EVLT_7330_uncapped

Argument | Description
------------ | -------------
card_port_num | 
session | 
### showCarrierDataDetail

Argument | Description
------------ | -------------
direction | far-end or near-end 
interface | interface identification
