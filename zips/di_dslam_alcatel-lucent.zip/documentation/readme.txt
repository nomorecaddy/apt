Project: Nokia Access
Description: Large library of QuickCalls and response maps for a variety of Nokia DSL and access systems (7330, 7302, 7450)
Category: library
Class: Community