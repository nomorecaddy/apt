### Project Information:
Project: Lucent Stinger DSLAM  
Description: QuickCalls and response maps useful for building system tests automating the Lucent Stinger DSLAM  
Category: library  
Class: Community  
  
___
### 1 QuickCall Library in project://di_dslam_lucent-stinger
### Library: project://di_dslam_lucent-stinger/session_profiles/stinger.fftc
___
### login
### getFootprint

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
footprint_data | 
### getLinkState

Argument | Description
------------ | -------------
card_name | 
card_port_num | 
### setDslamProfile

Argument | Description
------------ | -------------
card_port_num | 
card_name | 
dslam_profile | 
args | 
### getPortId

Argument | Description
------------ | -------------
card_port_num | \t
