Project: VMware vSphere
Description: Client QuickCalls and response maps
Category: library
Class: Community