1 QuickCall Library in project://ui_power_controller_wti
## Library: project://ui_power_controller_wti/session_profiles/power_controller_wti.fftc
### cpeOn

Argument | Description
------------ | -------------
power_controller_port | 
state | 
### cpeOff

Argument | Description
------------ | -------------
power_controller_port | 
### portOn

Argument | Description
------------ | -------------
portNumber | port number starting at 1 and ending in the max number of ports for the specified controller.
### portOff

Argument | Description
------------ | -------------
portNumber | 
### getPortState
Returns "ON" or "OFF"

Argument | Description
------------ | -------------
portNumber | 
### getNumPorts
### cyclePort

Argument | Description
------------ | -------------
portNumber | 
