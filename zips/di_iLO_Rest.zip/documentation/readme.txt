Project: ILO REST
Description: QuickCalls useful for automating ILO via its REST API
Category: framework
Class: Community